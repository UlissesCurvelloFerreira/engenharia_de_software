# TP2 — Refatoração de relatórios de cidades

Projeto em JavaScript ES modules para CI1221 Engenharia de Software. Requer Node.js 18 ou superior; não usa dependências npm externas.

## Execução
A partir da raiz do projeto:
```bash
node index.js --format=html --source=data/cidades-2.json
node index.js --format=txt --source=data/cidades-2.json
node index.js --format=csv --source=data/cidades.csv
node index.js --format=md --source=data/cidades.csv
npm test
```
A CLI também aceita argumentos separados, como `--format csv`. Formatos aceitos: `html`, `txt`, `csv`, `md` (ou `markdown`). Fontes aceitas: `.json` e `.csv`.

## Gerar as imagens dos diagramas
Instale Graphviz (com o comando `dot` no PATH) e execute:
```bash
python3 diagramas/gerar_diagramas.py
```
O script gera os arquivos `.dot` de fonte e os três PNGs usados no relatório dentro de `diagramas/`. O script pode ser executado novamente após ajustes no conteúdo dos diagramas.

## Recompilar o relatório
O PDF entregue já está em `relatorio.pdf`. Para compilar no Overleaf, envie `relatorio.tex` junto com a pasta `diagramas/` completa e selecione pdfLaTeX. Localmente, com uma instalação LaTeX que inclua os pacotes usados no preâmbulo:
```bash
pdflatex -interaction=nonstopmode relatorio.tex
pdflatex -interaction=nonstopmode relatorio.tex
```

## Estrutura e decisões
`src/readers/` lê JSON/CSV e converte para registros `{ name, id, state }`; `src/reporters/` produz HTML, TXT, CSV ou Markdown. As fábricas centralizam a seleção das estratégias. A CLI fica em `index.js`; os testes automatizados estão em `test/`.

A separação atende à Responsabilidade Única e favorece coesão alta e acoplamento baixo. Leitores e reporters oferecem operações comuns (`read`/`render`); as fábricas simples mantêm a escolha de implementação fora do fluxo principal e permitem extensão localizada. Ver o relatório para justificativas detalhadas e referência aos slides.
