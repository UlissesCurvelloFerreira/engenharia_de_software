#!/usr/bin/env node
import { createReader } from './src/readers/ReaderFactory.js';
import { createReporter } from './src/reporters/ReporterFactory.js';

function parseArgs(args) {
  const options = {};
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--help' || arg === '-h') return { help: true };
    const match = arg.match(/^--(format|source)=(.*)$/);
    if (match) options[match[1]] = match[2];
    else if (arg === '--format' || arg === '--source') options[arg.slice(2)] = args[++i];
    else throw new Error(`Argumento desconhecido ou inválido: ${arg}`);
  }
  if (!options.format || !options.source) throw new Error('Informe --format e --source.');
  return options;
}

const usage = `Uso: node index.js --format=<html|txt|csv|md> --source=<arquivo>\nExemplo: node index.js --format=html --source=data/cidades-2.json`;
try {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) { console.log(usage); process.exit(0); }
  const cities = await createReader(options.source).read(options.source);
  console.log(createReporter(options.format).render(cities));
} catch (error) {
  console.error(`Erro: ${error.message}\n\n${usage}`);
  process.exitCode = 1;
}
