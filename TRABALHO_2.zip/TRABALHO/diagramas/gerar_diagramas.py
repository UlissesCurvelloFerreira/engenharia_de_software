#!/usr/bin/env python3
"""Gera PNGs dos diagramas UML do trabalho usando Graphviz (dot).

Uso: python3 diagramas/gerar_diagramas.py
Requisito: executável Graphviz `dot` disponível no PATH.
As fontes DOT são mantidas ao lado do script e as imagens são gravadas nesta pasta.
"""
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
DIAGRAMS = {
    "diagrama1_sistema_original": r'''digraph G {
      graph [rankdir=TB, bgcolor="white", pad="0.25", nodesep="0.55", ranksep="0.68", fontname="Arial", label="Sistema original — responsabilidades misturadas", labelloc=t, fontsize=18];
      node [shape=box, style="rounded,filled", fillcolor="#F4F6F8", color="#64748B", fontname="Arial", fontsize=11, margin="0.16,0.10"];
      edge [color="#64748B", fontname="Arial", fontsize=9, arrowsize=0.75];
      cli [label="index.js\ncondicionais + seleção concreta", fillcolor="#E8EEF7"];
      html [label="CidadesHTMLReporter\nler() + parse() + reportar()"];
      txt [label="CidadesTXTReporter\nler() + parse() + reportar()"];
      json [label="cidades-2.json\nfonte fixa"];
      {rank=same; html; txt}
      cli -> html [label="instancia"];
      cli -> txt [label="instancia"];
      html -> json [label="lê e interpreta"];
      txt -> json [label="lê e interpreta"];
    }''',
    "diagrama2_arquitetura_refatorada": r'''digraph G {
      graph [rankdir=TB, bgcolor="white", pad="0.25", nodesep="0.48", ranksep="0.55", fontname="Arial", label="Arquitetura refatorada — fonte e formato selecionáveis", labelloc=t, fontsize=18];
      node [shape=box, style="rounded,filled", fillcolor="#F4F6F8", color="#64748B", fontname="Arial", fontsize=10, margin="0.14,0.10"];
      edge [color="#64748B", fontname="Arial", fontsize=9, arrowsize=0.72];
      cli [label="CLI / index.js\n--format + --source", fillcolor="#E8EEF7"];
      rf [label="ReaderFactory"];
      jf [label="JsonCityReader"];
      cf [label="CsvCityReader"];
      model [label="Cidades normalizadas\n{name, id, state}", fillcolor="#E8F3EC"];
      pf [label="ReporterFactory"];
      html [label="HtmlReporter"];
      txt [label="TxtReporter"];
      csv [label="CsvReporter"];
      md [label="MarkdownReporter"];
      {rank=same; jf; cf}
      {rank=same; html; txt}
      {rank=same; csv; md}
      cli -> rf [label="extensão"];
      rf -> jf [label=".json"];
      rf -> cf [label=".csv"];
      jf -> model [label="read(path)"];
      cf -> model [label="read(path)"];
      model -> pf [label="render(cities)"];
      pf -> html [label="html"];
      pf -> txt [label="txt"];
      pf -> csv [label="csv"];
      pf -> md [label="md"];
    }''',
    "diagrama3_classes_uml": r'''digraph G {
      graph [rankdir=TB, bgcolor="white", pad="0.25", nodesep="0.42", ranksep="0.60", fontname="Arial", label="Diagrama de classes — contratos e implementações", labelloc=t, fontsize=18];
      node [shape=plain, fontname="Arial", fontsize=10];
      edge [color="#64748B", fontname="Arial", fontsize=9, arrowsize=0.72];
      cli [label=< <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="6" COLOR="#64748B"><TR><TD BGCOLOR="#E8EEF7"><B>CLI</B></TD></TR><TR><TD ALIGN="LEFT">+ parseArgs(args)<BR ALIGN="LEFT"/>+ executa seleção</TD></TR></TABLE> >];
      read [label=< <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="6" COLOR="#64748B"><TR><TD BGCOLOR="#E8F3EC"><B>&lt;&lt;contrato&gt;&gt; Reader</B></TD></TR><TR><TD ALIGN="LEFT">+ read(path): City[]</TD></TR></TABLE> >];
      json [label=< <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="6" COLOR="#64748B"><TR><TD BGCOLOR="#F4F6F8"><B>JsonCityReader</B></TD></TR><TR><TD ALIGN="LEFT">+ read(path): City[]</TD></TR></TABLE> >];
      csvr [label=< <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="6" COLOR="#64748B"><TR><TD BGCOLOR="#F4F6F8"><B>CsvCityReader</B></TD></TR><TR><TD ALIGN="LEFT">+ read(path): City[]</TD></TR></TABLE> >];
      reporter [label=< <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="6" COLOR="#64748B"><TR><TD BGCOLOR="#E8F3EC"><B>&lt;&lt;contrato&gt;&gt; Reporter</B></TD></TR><TR><TD ALIGN="LEFT">+ render(cities): string</TD></TR></TABLE> >];
      formats [label=< <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="6" COLOR="#64748B"><TR><TD BGCOLOR="#F4F6F8"><B>HtmlReporter | TxtReporter</B></TD></TR><TR><TD ALIGN="LEFT">CsvReporter | MarkdownReporter<BR ALIGN="LEFT"/>+ render(cities): string</TD></TR></TABLE> >];
      city [label=< <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="6" COLOR="#64748B"><TR><TD BGCOLOR="#FFF5E6"><B>City (registro normalizado)</B></TD></TR><TR><TD ALIGN="LEFT">name: string<BR ALIGN="LEFT"/>id: string<BR ALIGN="LEFT"/>state: string</TD></TR></TABLE> >];
      cli -> read [style=dashed, label="seleciona via factory"];
      cli -> reporter [style=dashed, label="seleciona via factory"];
      json -> read [arrowhead=empty, label="implementa"];
      csvr -> read [arrowhead=empty];
      formats -> reporter [arrowhead=empty, label="implementam"];
      json -> city [label="normaliza"];
      csvr -> city [label="normaliza"];
      reporter -> city [style=dashed, label="consome"];
      {rank=same; json; csvr}
    }''',
}


def main():
    dot = shutil.which("dot")
    if not dot:
        print("Erro: Graphviz não foi encontrado. Instale Graphviz e tente novamente.", file=sys.stderr)
        return 1
    for name, source in DIAGRAMS.items():
        dot_file = HERE / f"{name}.dot"
        png_file = HERE / f"{name}.png"
        dot_file.write_text(source + "\n", encoding="utf-8")
        subprocess.run([dot, "-Tpng", str(dot_file), "-o", str(png_file)], check=True)
        print(f"Gerado: {png_file.name}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
