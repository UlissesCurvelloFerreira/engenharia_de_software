import { readFile } from 'node:fs/promises';

// Parser pequeno compatível com campos entre aspas, vírgulas e aspas escapadas.
function parseCsv(text) {
  const rows = []; let row = []; let field = ''; let quoted = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') { field += '"'; i++; }
      else if (ch === '"') quoted = false;
      else field += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ',') { row.push(field); field = ''; }
    else if (ch === '\n') { row.push(field.replace(/\r$/, '')); rows.push(row); row = []; field = ''; }
    else field += ch;
  }
  if (quoted) throw new Error('CSV inválido: campo com aspas não terminadas.');
  if (field.length || row.length) { row.push(field.replace(/\r$/, '')); rows.push(row); }
  return rows.filter((r) => r.some((v) => v.trim() !== ''));
}

export default class CsvCityReader {
  async read(path) {
    const rows = parseCsv(await readFile(path, 'utf8'));
    if (rows.length < 1) throw new Error('CSV vazio.');
    const headers = rows.shift().map((h) => h.trim().toLocaleUpperCase('pt-BR'));
    const nameIndex = headers.indexOf('NOME') >= 0 ? headers.indexOf('NOME') : headers.indexOf('NOME DA CIDADE');
    if (nameIndex < 0) throw new Error('CSV sem coluna NOME.');
    const idIndex = headers.indexOf('COD');
    const stateIndex = headers.indexOf('COD UF');
    return rows.map((r, i) => {
      const name = r[nameIndex]?.trim();
      if (!name) throw new Error(`Registro CSV ${i + 2} sem nome válido.`);
      return { name, id: idIndex >= 0 ? (r[idIndex] ?? '').trim() : '', state: stateIndex >= 0 ? (r[stateIndex] ?? '').trim() : '' };
    });
  }
}
