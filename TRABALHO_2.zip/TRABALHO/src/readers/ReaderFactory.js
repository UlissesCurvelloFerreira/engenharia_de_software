import JsonCityReader from './JsonCityReader.js';
import CsvCityReader from './CsvCityReader.js';

const readers = new Map([['.json', JsonCityReader], ['.csv', CsvCityReader]]);
export function createReader(source) {
  const ext = source.slice(source.lastIndexOf('.')).toLowerCase();
  const Reader = readers.get(ext);
  if (!Reader) throw new Error(`Fonte não suportada: ${ext || '(sem extensão)'}. Use .json ou .csv.`);
  return new Reader();
}
