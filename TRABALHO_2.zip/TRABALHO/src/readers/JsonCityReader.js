import { readFile } from 'node:fs/promises';

export default class JsonCityReader {
  async read(path) {
    const parsed = JSON.parse(await readFile(path, 'utf8'));
    if (!Array.isArray(parsed)) throw new Error('O JSON deve conter uma lista de cidades.');
    return parsed.map((row, i) => {
      const name = row.Nome ?? row.nome ?? row.NOME;
      if (typeof name !== 'string' || !name.trim()) throw new Error(`Registro JSON ${i + 1} sem nome válido.`);
      return { name: name.trim(), id: row.ID ?? row.COD ?? '', state: row.Estado ?? row.UF ?? row['COD UF'] ?? '' };
    });
  }
}
