import HtmlReporter from './HtmlReporter.js';
import TxtReporter from './TxtReporter.js';
import CsvReporter from './CsvReporter.js';
import MarkdownReporter from './MarkdownReporter.js';

const reporters = new Map([['html', HtmlReporter], ['txt', TxtReporter], ['csv', CsvReporter], ['md', MarkdownReporter], ['markdown', MarkdownReporter]]);
export function createReporter(format) {
  const Reporter = reporters.get(format.toLowerCase());
  if (!Reporter) throw new Error(`Formato não suportado: ${format}. Use html, txt, csv ou md.`);
  return new Reporter();
}
