export default class TxtReporter {
  render(cities) { return `Relatório de Nomes de Cidades\n=============================\n${cities.map(({ name }) => `* ${name}`).join('\n')}\n`; }
}
