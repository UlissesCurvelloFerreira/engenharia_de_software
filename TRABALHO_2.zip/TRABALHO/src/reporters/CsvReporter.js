const csvCell = (value) => `"${String(value).replaceAll('"', '""')}"`;
export default class CsvReporter {
  render(cities) { return ['Nome', ...cities.map(({ name }) => csvCell(name))].join('\n') + '\n'; }
}
