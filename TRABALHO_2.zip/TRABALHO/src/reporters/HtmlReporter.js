const escapeHtml = (value) => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#39;');
export default class HtmlReporter {
  render(cities) {
    const items = cities.map(({ name }) => `      <li>${escapeHtml(name)}</li>`).join('\n');
    return `<!doctype html>\n<html lang="pt-BR">\n<head>\n  <meta charset="utf-8">\n  <title>Relatório de cidades</title>\n</head>\n<body>\n  <h1>Relatório de nomes de cidades</h1>\n  <ul>\n${items}\n  </ul>\n</body>\n</html>\n`;
  }
}
