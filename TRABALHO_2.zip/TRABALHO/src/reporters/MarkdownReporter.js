const escapeMarkdown = (s) => String(s).replaceAll('\\', '\\\\').replaceAll('|', '\\|').replaceAll('\n', ' ');
export default class MarkdownReporter {
  render(cities) { return `# Relatório de cidades\n\n${cities.map(({ name }) => `- ${escapeMarkdown(name)}`).join('\n')}\n`; }
}
