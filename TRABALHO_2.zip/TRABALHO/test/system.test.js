import test from 'node:test';
import assert from 'node:assert/strict';
import { createReader } from '../src/readers/ReaderFactory.js';
import { createReporter } from '../src/reporters/ReporterFactory.js';

const jsonPath = new URL('../data/cidades-2.json', import.meta.url).pathname;
const csvPath = new URL('../data/cidades.csv', import.meta.url).pathname;
test('JSON: lê e normaliza cidades', async () => {
  const cities = await createReader(jsonPath).read(jsonPath);
  assert.ok(cities.length > 0); assert.equal(cities[0].name, 'Afonso Cláudio');
});
test('CSV: lê e normaliza cidades incluindo apóstrofo', async () => {
  const cities = await createReader(csvPath).read(csvPath);
  assert.ok(cities.length > 5000); assert.ok(cities.some((c) => c.name === "Alta Floresta D'oeste"));
});
test('reporters suportam HTML, TXT, CSV e Markdown', () => {
  const cities = [{ name: 'A&B' }];
  assert.match(createReporter('html').render(cities), /A&amp;B/);
  assert.match(createReporter('txt').render(cities), /\* A&B/);
  assert.match(createReporter('csv').render(cities), /"A&B"/);
  assert.match(createReporter('md').render(cities), /- A&B/);
});
test('falha explicitamente em extensões e formatos desconhecidos', () => {
  assert.throws(() => createReader('x.xml'), /Fonte não suportada/);
  assert.throws(() => createReporter('pdf'), /Formato não suportado/);
});
